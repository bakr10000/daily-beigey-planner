/* Daily Beigey Planner service worker
   Bump VERSION on every deploy so users receive the new files. */
const VERSION = 'v1';
const SHELL = `beigey-shell-${VERSION}`;
const RUNTIME = `beigey-runtime-${VERSION}`;
const SHELL_FILES = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/maskable-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(SHELL).then((cache) => cache.addAll(SHELL_FILES)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys.filter((k) => k.startsWith('beigey-') && k !== SHELL && k !== RUNTIME).map((k) => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});

// Serve from cache instantly, refresh in the background.
async function staleWhileRevalidate(request, cacheName) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request);
  const network = fetch(request)
    .then((res) => {
      if (res && (res.ok || res.type === 'opaque')) cache.put(request, res.clone());
      return res;
    })
    .catch(() => null);
  return cached || (await network) || Response.error();
}

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);

  // Page navigations: app shell first, so the planner opens offline.
  if (request.mode === 'navigate') {
    event.respondWith(
      caches.match('./index.html').then((cached) => {
        const refresh = fetch(request)
          .then((res) => {
            if (res.ok) caches.open(SHELL).then((c) => c.put('./index.html', res.clone()));
            return res;
          })
          .catch(() => null);
        return cached || refresh.then((r) => r || caches.match('./'));
      })
    );
    return;
  }

  // Same-origin assets and Google Fonts: stale-while-revalidate.
  if (url.origin === self.location.origin ||
      url.hostname === 'fonts.googleapis.com' ||
      url.hostname === 'fonts.gstatic.com') {
    event.respondWith(staleWhileRevalidate(request, url.origin === self.location.origin ? SHELL : RUNTIME));
  }
});
